# Documentation

The conversion and upgrade of Hex Map is an incremental process. This is also true for the documentation, which is still very sparse. The [Hex Map tutorial series](https://catlikecoding.com/unity/tutorials/hex-map/) currently functions as the documentation, explaining why and how everything was made in the past. The project documentation explains everything new and changed. At some point in the future the project will be completely self-documenting. 

This is a Unity 2021 LTS Project. Opening it in a higher Unity versions will likely break things.

- [Graphics](graphics/index.md)
